const compromised = [
  'Nom et prénom',
  'Date et lieu de naissance',
  'Numéro de sécurité sociale (NIR)',
  'Identifiant France Travail',
  'Adresse électronique',
  'Adresse postale',
  'Numéro de téléphone',
]

const preserved = [
  'Mots de passe',
  'Coordonnées bancaires (RIB)',
  'Données d’indemnisation',
  'Justificatifs personnels déposés en ligne',
]

const diffusion = [
  {
    title: 'Une donnée qui ne se révoque pas',
    text:
      'Un mot de passe se change, un RIB se remplace. Un numéro de sécurité sociale, une date de naissance et un lieu de naissance accompagnent une personne toute sa vie. C’est ce qui rend cette fuite durablement exploitable, bien au-delà de 2024.',
    source: 'Analyse — RGPD, article 9 et suivants',
  },
  {
    title: 'Revente et recoupement',
    text:
      'Selon Zataz, les données ont circulé sur des places de marché clandestines et des canaux privés de type Telegram, puis ont été recoupées avec des fuites antérieures. Le croisement de plusieurs bases permet de reconstituer des profils bien plus complets que chaque fuite prise isolément.',
    source: 'Zataz',
  },
]

function DonneesSection() {
  return (
    <section className="section-contenu">
      <div className="mb-4">
        <span className="surtitre">III. Données exposées</span>
        <h3 className="h2 fw-bold text-dark">Quelles données ont été exposées et diffusées ?</h3>
      </div>

      <div className="row g-4">
        <div className="col-lg-6">
          <div className="panneau-liste h-100">
            <h4 className="h5 fw-bold text-dark mb-3">Données compromises</h4>
            <ul className="mb-0 ps-3 text-secondary">
              {compromised.map((item) => (
                <li key={item} className="mb-2">
                  {item}
                </li>
              ))}
            </ul>
            <small className="source-label d-block mt-3">
              Source : France Travail, communiqué du 13 mars 2024
            </small>
          </div>
        </div>

        <div className="col-lg-6">
          <div className="panneau-liste panneau-avertissement h-100">
            <h4 className="h5 fw-bold text-dark mb-3">Données préservées</h4>
            <ul className="mb-0 ps-3 text-secondary">
              {preserved.map((item) => (
                <li key={item} className="mb-2">
                  {item}
                </li>
              ))}
            </ul>
            <p className="text-secondary mt-3 mb-0">
              France Travail en conclut qu’il n’existe pas de risque direct de détournement des
              indemnisations ou des comptes bancaires. Le risque se déplace vers l’usurpation
              d’identité et la fraude par manipulation.
            </p>
            <small className="source-label d-block mt-3">
              Source : France Travail, communiqué du 13 mars 2024
            </small>
          </div>
        </div>
      </div>

      <div className="row g-4 mt-1">
        {diffusion.map((item) => (
          <div className="col-lg-6" key={item.title}>
            <article className="card h-100 border-0 shadow-sm rounded-4">
              <div className="card-body">
                <h4 className="h5 fw-bold text-dark mb-3">{item.title}</h4>
                <p className="mb-0 text-secondary">{item.text}</p>
                <small className="source-label d-block mt-3">Source : {item.source}</small>
              </div>
            </article>
          </div>
        ))}
      </div>
    </section>
  )
}

export default DonneesSection
