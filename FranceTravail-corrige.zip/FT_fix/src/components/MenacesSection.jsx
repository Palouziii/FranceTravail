const risks = [
  {
    icon: '📞',
    title: 'Fraude téléphonique et usurpation',
    text:
      'Un escroc disposant du nom, de la date de naissance et de l’identifiant France Travail d’une victime peut l’appeler en se faisant passer pour l’organisme, sa banque ou l’Assurance Maladie. La connaissance de ces données rend l’appel crédible et abaisse la méfiance : c’est le principal risque concret issu de cette fuite.',
    source: 'CNIL — recommandations aux personnes concernées',
  },
  {
    icon: '📧',
    title: 'Hameçonnage ciblé',
    text:
      'Contrairement au hameçonnage de masse, les courriels et SMS construits à partir de données réelles sont personnalisés et donc nettement plus difficiles à repérer. Un message mentionnant le véritable identifiant France Travail du destinataire passe aisément pour authentique.',
    source: 'ANSSI — bonnes pratiques',
  },
  {
    icon: '🧑‍💼',
    title: 'Usurpation d’identité administrative',
    text:
      'Le numéro de sécurité sociale est une clé d’identification utilisée par de nombreux organismes. Associé à un état civil complet, il ouvre la voie à l’ouverture de dossiers frauduleux et au détournement de démarches, au détriment des droits des victimes.',
    source: 'Analyse — France Travail, CNIL',
  },
  {
    icon: '🏛️',
    title: 'Conséquences pour l’organisation',
    text:
      'Au-delà des victimes, l’incident coûte à France Travail une amende de 5 millions d’euros, une injonction de renforcement de ses dispositifs, une procédure pénale et une perte de confiance dans un service public dont l’usage n’est pas facultatif pour les demandeurs d’emploi.',
    source: 'CNIL, délibération du 22 janvier 2026',
  },
]

function MenacesSection() {
  return (
    <section className="section-contenu fond-alternatif">
      <div className="mb-4">
        <span className="surtitre">IV. Menaces &amp; conséquences</span>
        <h3 className="h2 fw-bold text-dark">Quels risques pour les victimes et l’organisation ?</h3>
      </div>

      <div className="row g-4">
        {risks.map((item) => (
          <div className="col-lg-3 col-md-6" key={item.title}>
            <article className="card h-100 border-0 shadow-sm rounded-4">
              <div className="card-body">
                <div className="icone-carte" aria-hidden="true">
                  {item.icon}
                </div>
                <h4 className="h5 fw-bold text-dark mb-3">{item.title}</h4>
                <p className="mb-0 text-secondary">{item.text}</p>
                <small className="source-label d-block mt-3">Source : {item.source}</small>
              </div>
            </article>
          </div>
        ))}
      </div>

      <div className="boit-sous-section">
        <h4 className="h5 fw-bold text-dark mb-3">Si vous êtes concerné</h4>
        <ul className="liste-sans-puce text-secondary mb-0">
          <li>
            Aucun organisme légitime ne demande par téléphone ou par courriel un mot de passe, un
            code de validation ou un RIB. Toute demande de ce type est frauduleuse.
          </li>
          <li>
            En cas d’appel suspect, raccrocher et rappeler soi-même l’organisme via un numéro
            officiel, jamais via celui fourni par l’interlocuteur.
          </li>
          <li>
            Activer la double authentification partout où elle est proposée, en particulier sur la
            messagerie électronique, qui sert à réinitialiser les autres comptes.
          </li>
          <li>
            Les signalements peuvent être faits sur les dispositifs publics d’assistance aux
            victimes d’actes de cybermalveillance.
          </li>
        </ul>
      </div>
    </section>
  )
}

export default MenacesSection
