# Cyberattaque France Travail — le bilan

Site d'analyse réalisé dans le cadre du **Sujet 24 : bilan de l'attaque subie par France Travail**.
IUT de Dijon-Auxerre-Nevers — Université de Bourgogne Europe.

## Objet

Entre le 6 février et le 5 mars 2024, France Travail a subi une exfiltration massive de données
personnelles à partir de comptes de conseillers Cap emploi compromis. Ce site en fait le bilan :
chronologie, causes techniques et organisationnelles, données exposées, menaces pour les victimes,
mesures de protection, suites réglementaires et récidive de juillet 2025.

## Plan du site

| Section | Contenu |
|---|---|
| Accueil | Synthèse et chiffres clés |
| I. Contexte & chronologie | Déroulement de l'incident, du vol d'identifiants aux interpellations |
| II. Causes & vulnérabilités | Vecteur d'attaque et défaillances exploitées |
| III. Données exposées | Données compromises, données préservées, diffusion |
| IV. Menaces & conséquences | Risques pour les victimes et pour l'organisation |
| V. Protections | Contre-mesures techniques et organisationnelles |
| VI. Bilan & récidive | Sanction CNIL, attaque Kairos de 2025, enseignements |
| Sources | Références datées et vérifiables |

## Stack

- React 18 + Vite 5
- Bootstrap 5 (grille et utilitaires) + feuille de style personnalisée aux couleurs de l'université

## Lancer le projet

```bash
npm install
npm run dev      # serveur de développement
npm run build    # build de production dans dist/
npm run preview  # prévisualisation du build
npm run lint     # ESLint
```

## Note méthodologique

Les affirmations du site sont rattachées à une source identifiable, listée dans la section
« Sources ». Lorsque les sources divergent — notamment sur le nombre de personnes concernées —
l'écart est explicité plutôt que masqué.
