import PropTypes from 'prop-types'

const reperes = [
  { valeur: '27 jours', libelle: 'd’exfiltration continue sans déclenchement d’alerte interne' },
  { valeur: '8 jours', libelle: 'entre la fin de l’attaque et sa révélation publique' },
  { valeur: '5 M€', libelle: 'd’amende prononcée par la CNIL le 22 janvier 2026' },
  { valeur: '2 attaques', libelle: 'en 16 mois, toutes deux par un accès partenaire compromis' },
]

function HomeSection({ setActiveSection }) {
  return (
    <section className="section-contenu">
      <div className="mb-4">
        <span className="surtitre">Accueil</span>
        <h3 className="h2 fw-bold text-dark">De quoi parle-t-on exactement ?</h3>
      </div>

      <div className="row g-4">
        <div className="col-lg-7">
          <p className="text-secondary">
            Entre le 6 février et le 5 mars 2024, des attaquants ont utilisé des comptes légitimes de
            conseillers du réseau Cap emploi pour interroger massivement la base nationale des
            demandeurs d’emploi. Il n’y a eu ni intrusion réseau, ni exploitation d’une faille
            logicielle : l’attaque a consisté à se servir d’un accès autorisé bien au-delà de ce que
            son titulaire aurait dû pouvoir faire.
          </p>
          <p className="text-secondary mb-0">
            C’est précisément ce qui rend ce cas instructif. Les contre-mesures classiques — pare-feu,
            antivirus, correctifs — n’auraient rien changé. Ce qui a manqué relève du contrôle
            d’accès, de la limitation des habilitations et de la détection des comportements
            anormaux.
          </p>
        </div>

        <div className="col-lg-5">
          <div className="panneau-liste panneau-avertissement h-100">
            <h4 className="h6 fw-bold text-dark mb-3">Pourquoi trois chiffres différents ?</h4>
            <ul className="liste-sans-puce text-secondary mb-0">
              <li>
                <strong>43 millions</strong> — chiffre communiqué par France Travail. C’est le nombre
                maximal de personnes dont les données <em>pouvaient</em> être concernées, publié par
                prudence en l’absence de certitude sur le volume réellement exfiltré.
              </li>
              <li>
                <strong>36,8 millions</strong> — volume retenu par la CNIL dans sa décision de
                sanction de janvier 2026.
              </li>
              <li>
                <strong>~3 %</strong> — part des données effectivement dérobées selon une information
                publiée fin mars 2024 par Next (ex-NextInpact), soit tout de même plus d’un million
                de personnes.
              </li>
            </ul>
            <small className="source-label d-block mt-3">
              Voir la section Sources pour les références complètes
            </small>
          </div>
        </div>
      </div>

      <div className="boit-sous-section">
        <h4 className="h5 fw-bold text-dark mb-3">Quatre repères</h4>
        <div className="row g-3">
          {reperes.map((item) => (
            <div className="col-lg-3 col-sm-6" key={item.valeur}>
              <div className="repere-bloc h-100">
                <strong className="d-block">{item.valeur}</strong>
                <span>{item.libelle}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="boit-sous-section">
        <h4 className="h5 fw-bold text-dark mb-3">Parcours de lecture</h4>
        <p className="text-secondary">
          Les sections I à IV reconstituent l’incident : comment il s’est déroulé, pourquoi il a été
          possible, ce qui a fuité et ce que risquent les victimes. La section V propose les
          protections, la section VI tire le bilan — y compris la récidive de juillet 2025, qui
          montre que le problème n’était pas réglé.
        </p>
        <div className="d-flex flex-wrap gap-3">
          <button
            type="button"
            className="btn btn-primary rounded-pill fw-bold px-4"
            onClick={() => setActiveSection('contexte')}
          >
            Commencer par la chronologie
          </button>
          <button
            type="button"
            className="btn btn-outline-dark rounded-pill fw-bold px-4"
            onClick={() => setActiveSection('bilan')}
          >
            Aller directement au bilan
          </button>
        </div>
      </div>
    </section>
  )
}

HomeSection.propTypes = {
  setActiveSection: PropTypes.func.isRequired,
}

export default HomeSection
