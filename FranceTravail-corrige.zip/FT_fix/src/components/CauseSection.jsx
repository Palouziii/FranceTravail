const faille = [
  {
    icon: '🔑',
    title: 'Compromission des identifiants',
    text:
      'Des identifiants de conseillers Cap emploi ont été dérobés par ingénierie sociale, puis réutilisés pour se faire passer pour des agents habilités. Les attaquants disposaient ainsi de comptes parfaitement valides aux yeux du système.',
    source: 'France Travail / Zataz',
  },
  {
    icon: '🎯',
    title: 'Un accès partenaire trop large',
    text:
      'Les conseillers Cap emploi disposaient d’un accès légitime au module de recherche d’usagers. Le problème n’est pas cet accès en soi, mais son étendue : un compte destiné à un suivi individuel permettait d’interroger la base nationale sans restriction de périmètre ni de volume.',
    source: 'CNIL, délibération du 22 janvier 2026',
  },
  {
    icon: '📞',
    title: 'Ingénierie sociale comme point d’entrée',
    text:
      'Le point d’entrée n’est pas technique mais humain. Zataz décrit des appels téléphoniques frauduleux visant les conseillers (vishing). Les sources officielles se bornent à constater l’usurpation des comptes : la méthode exacte n’a pas été confirmée publiquement.',
    source: 'Zataz (méthode non confirmée officiellement)',
  },
]

const vuln = [
  {
    icon: '🔐',
    title: 'Authentification à facteur unique',
    text:
      'Les partenaires externes pouvaient se connecter à la base nationale avec un simple couple identifiant / mot de passe. Un identifiant volé suffisait donc à ouvrir la porte, sans aucune vérification supplémentaire.',
    source: 'CNIL, délibération du 22 janvier 2026',
  },
  {
    icon: '🧱',
    title: 'Habilitations non cloisonnées',
    text:
      'Un conseiller pouvait interroger la base au-delà de son périmètre géographique et professionnel. Le principe du moindre privilège n’était pas appliqué : la compromission d’un seul compte exposait des dizaines de millions d’enregistrements.',
    source: 'CNIL, délibération du 22 janvier 2026',
  },
  {
    icon: '🚨',
    title: 'Absence de détection des volumes anormaux',
    text:
      'Aucune alerte automatique ne se déclenchait face à des requêtes massives issues d’un compte unique. L’extraction a pu se poursuivre près d’un mois sans être repérée, faute de surveillance du comportement des utilisateurs.',
    source: 'CNIL, délibération du 22 janvier 2026',
  },
]

function CauseSection() {
  return (
    <section className="section-contenu fond-alternatif">
      <div className="mb-4">
        <span className="surtitre">II. Causes &amp; vulnérabilités</span>
        <h3 className="h2 fw-bold text-dark">Comment les failles ont-elles été exploitées ?</h3>
      </div>

      <div className="row g-4 mb-4">
        {faille.map((item) => (
          <div className="col-lg-4" key={item.title}>
            <article className="card h-100 border-0 shadow-sm rounded-4">
              <div className="card-body">
                <div className="icone-carte" aria-hidden="true">
                  {item.icon}
                </div>
                <h4 className="h5 fw-bold text-dark mb-3">{item.title}</h4>
                <p className="mb-0 text-secondary">{item.text}</p>
                <small className="source-label d-block mt-3">Source : {item.source}</small>
              </div>
            </article>
          </div>
        ))}
      </div>

      <div className="boit-sous-section">
        <h4 className="h5 fw-bold text-dark mb-3">Chaîne d’attaque</h4>
        <div className="chaine-attaque" aria-label="Chaîne d’attaque en quatre étapes">
          <span className="chaine-etape">Ingénierie sociale visant des conseillers Cap emploi</span>
          <span className="fleche-attaque" aria-hidden="true">
            →
          </span>
          <span className="chaine-etape">Vol d’identifiants</span>
          <span className="fleche-attaque" aria-hidden="true">
            →
          </span>
          <span className="chaine-etape">Connexion légitime à la base nationale</span>
          <span className="fleche-attaque" aria-hidden="true">
            →
          </span>
          <span className="chaine-etape">Requêtes massives et exfiltration</span>
        </div>
        <p className="text-secondary mt-3 mb-0">
          Chaque maillon correspond à une occasion manquée de bloquer l’attaque : un facteur
          d’authentification supplémentaire aurait neutralisé l’étape 2, un cloisonnement des
          habilitations aurait limité l’étape 3, une détection des volumes anormaux aurait
          interrompu l’étape 4 bien avant la fin du mois.
        </p>
      </div>

      <div className="boit-sous-section">
        <h4 className="h5 fw-bold text-dark mb-3 mt-4">Vulnérabilités du système</h4>
        <div className="row g-4">
          {vuln.map((item) => (
            <div className="col-lg-4" key={item.title}>
              <article className="card h-100 border-0 shadow-sm rounded-4">
                <div className="card-body">
                  <div className="icone-carte" aria-hidden="true">
                    {item.icon}
                  </div>
                  <h4 className="h5 fw-bold text-dark mb-3">{item.title}</h4>
                  <p className="mb-0 text-secondary">{item.text}</p>
                  <small className="source-label d-block mt-3">Source : {item.source}</small>
                </div>
              </article>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default CauseSection
