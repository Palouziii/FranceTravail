const manquements = [
  {
    title: 'Défaut d’authentification multifacteur',
    text:
      'Les partenaires externes accédaient à la base nationale avec un simple identifiant et mot de passe, sans validation supplémentaire.',
  },
  {
    title: 'Absence de filtrage des requêtes',
    text:
      'Un conseiller pouvait interroger la base au-delà de ses besoins géographiques et professionnels, sans limitation stricte.',
  },
  {
    title: 'Manque de détection',
    text:
      'L’absence d’alertes automatisées sur les téléchargements massifs et inhabituels a permis à l’attaque d’échapper aux contrôles pendant près d’un mois.',
  },
]

function BilanSection() {
  return (
    <section className="section-contenu fond-alternatif">
      <div className="mb-4">
        <span className="surtitre">VI. Bilan &amp; récidive</span>
        <h3 className="h2 fw-bold text-dark">Ce que l’incident a réellement coûté, et ce qu’il a changé</h3>
      </div>

      <div className="chronologie-bloc">
        <h4 className="h5 fw-bold text-dark mb-3">Un antécédent, puis une récidive</h4>
        <ol className="chronologie-liste">
          <li>
            <span className="date-chronologie">Août 2023 — Pôle emploi, 10 millions de personnes</span>
            <p>
              Avant même l’attaque de 2024, le prédécesseur de France Travail avait déjà subi une
              cyberattaque concernant environ 10 millions de personnes. L’incident de 2024 ne
              survient donc pas sur un terrain vierge.
            </p>
          </li>
          <li>
            <span className="date-chronologie">Février – mars 2024 — l’attaque principale</span>
            <p>
              Exfiltration via des comptes Cap emploi compromis. Jusqu’à 43 millions de personnes
              potentiellement concernées, 36,8 millions selon le volume retenu par la CNIL.
            </p>
          </li>
          <li>
            <span className="date-chronologie">12 – 23 juillet 2025 — l’application Kairos</span>
            <p>
              Le CERT-FR alerte France Travail le 12 juillet d’une action malveillante. La cible est
              <strong> Kairos</strong>, l’application permettant aux organismes de formation de
              suivre les parcours des demandeurs d’emploi. L’intrusion provient du compte compromis
              d’un organisme de formation isérois, piraté au moyen d’un <em>infostealer</em>, un
              logiciel voleur d’identifiants. Les données de 340 000 demandeurs d’emploi ont été
              consultées : nom, prénom, date de naissance, identifiant France Travail, adresses et
              numéros de téléphone. Le service est fermé immédiatement et le déploiement de la
              double authentification sur Kairos, initialement prévu pour octobre, est accéléré.
            </p>
          </li>
          <li>
            <span className="date-chronologie">22 janvier 2026 — la sanction</span>
            <p>
              La CNIL prononce une amende de 5 millions d’euros contre France Travail au titre de
              l’article 32 du RGPD, estimant que les mesures de sécurité n’étaient pas à la hauteur
              du risque pesant sur les données. France Travail prend acte de la décision, ne forme
              pas de recours, mais en regrette la sévérité.
            </p>
          </li>
        </ol>
        <small className="source-label d-block mt-3">
          Sources : Assemblée nationale, Banque des Territoires, Solutions Numériques, franceinfo —
          voir la section Sources
        </small>
      </div>

      <div className="boit-sous-section">
        <h4 className="h5 fw-bold text-dark mb-3">Les manquements retenus par la CNIL</h4>
        <div className="row g-4">
          {manquements.map((item) => (
            <div className="col-lg-4" key={item.title}>
              <article className="card h-100 border-0 shadow-sm rounded-4">
                <div className="card-body">
                  <h4 className="h6 fw-bold text-dark mb-2">{item.title}</h4>
                  <p className="mb-0 text-secondary">{item.text}</p>
                </div>
              </article>
            </div>
          ))}
        </div>
        <p className="text-secondary mt-3 mb-0">
          La CNIL ne s’est pas limitée à la sanction financière : elle exige également des mesures
          renforcées de suivi de l’activité informatique, afin de détecter les comportements
          anormaux — typiquement un utilisateur qui exfiltre un volume excessif de données.
          Autrement dit, l’autorité impose précisément la contre-mesure décrite en section V.
        </p>
        <small className="source-label d-block mt-3">
          Source : CNIL, délibération du 22 janvier 2026
        </small>
      </div>

      <div className="boit-sous-section">
        <h4 className="h5 fw-bold text-dark mb-3">Mise en perspective</h4>
        <p className="text-secondary">
          L’attaque de France Travail n’est pas un cas isolé. Au début de la même année 2024, la
          CNIL ouvrait une enquête sur la violation de données des opérateurs de tiers payant
          Viamedis et Almerys, touchant plus de 33 millions de personnes en France. En quelques
          semaines, deux fuites à l’échelle de la population active ont donc visé des organismes
          détenant des données que les citoyens ne peuvent pas choisir de ne pas confier.
        </p>
        <p className="text-secondary mb-0">
          Cette répétition explique la fermeté de la sanction de 2026 : au-delà du cas particulier,
          la décision adresse un signal à l’ensemble des opérateurs publics manipulant des données
          personnelles à grande échelle.
        </p>
      </div>

      <div className="boit-sous-section">
        <h4 className="h5 fw-bold text-dark mb-3">Conclusion</h4>
        <p className="text-secondary">
          Trois enseignements se dégagent de ce dossier. D’abord, <strong>le périmètre d’un compte
          compte plus que sa protection</strong> : si un seul identifiant de conseiller n’avait
          donné accès qu’à son département, l’incident aurait concerné quelques milliers de
          personnes au lieu de dizaines de millions. Ensuite,{' '}
          <strong>l’absence de détection transforme un incident en catastrophe</strong> : la
          différence entre quatre semaines et quatre heures d’exfiltration se mesure en ordres de
          grandeur.
        </p>
        <p className="text-secondary mb-0">
          Enfin, et c’est le point le plus net,{' '}
          <strong>la chaîne de sous-traitance est la surface d’attaque réelle</strong>. En 2024 comme
          en 2025, les attaquants ne s’en sont pas pris à France Travail directement : ils sont
          entrés par un partenaire. Tant que le niveau de sécurité exigé des tiers restera
          inférieur à celui du système qu’ils consultent, c’est par eux que les attaques
          continueront de passer. La récidive de juillet 2025, seize mois après la première
          attaque et sur le même schéma, en est la démonstration.
        </p>
      </div>
    </section>
  )
}

export default BilanSection
