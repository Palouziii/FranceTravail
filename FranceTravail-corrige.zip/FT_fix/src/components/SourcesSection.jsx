const sources = [
  {
    categorie: 'Sources primaires et institutionnelles',
    items: [
      {
        auteur: 'France Travail',
        titre: 'France Travail et Cap emploi victimes d’une cyberattaque',
        date: '13 mars 2024',
        url: 'https://www.francetravail.org/accueil/communiques/2024/france-travail-et-cap-emploi-victimes-dune-cyberattaque.html',
        usage: 'Communiqué officiel : périmètre de la fuite, nature des données, mesures immédiates.',
      },
      {
        auteur: 'CNIL',
        titre: 'RGPD — article 32 (sécurité du traitement)',
        date: 'Texte en vigueur',
        url: 'https://www.cnil.fr/fr/reglement-europeen-protection-donnees/chapitre4#Article32',
        usage: 'Fondement juridique de la sanction prononcée contre France Travail.',
      },
      {
        auteur: 'CNIL',
        titre: 'RGPD — articles 33 et 34 (notification des violations)',
        date: 'Texte en vigueur',
        url: 'https://www.cnil.fr/fr/reglement-europeen-protection-donnees/chapitre4#Article33',
        usage: 'Délai de 72 heures et obligation d’information des personnes concernées.',
      },
      {
        auteur: 'Assemblée nationale',
        titre: 'Question écrite n° 16322 — Cyberattaque à France Travail',
        date: '19 mars 2024',
        url: 'https://www.assemblee-nationale.fr/dyn/16/questions/QANR5L16QE16322',
        usage: 'Mise en perspective parlementaire ; rappel de la cyberattaque de Pôle emploi d’août 2023.',
      },
    ],
  },
  {
    categorie: 'Analyses techniques et presse spécialisée',
    items: [
      {
        auteur: 'Zataz',
        titre: 'France Travail : l’analyse détaillée deux mois après',
        date: '2024',
        url: 'https://www.zataz.com/',
        usage: 'Source de référence du sujet. Description du mode opératoire et de la circulation des données.',
      },
      {
        auteur: 'IT-Connect (Florian Burnel)',
        titre: 'Cyberattaque France Travail : 43 millions de personnes menacées par une fuite de données',
        date: '14 mars 2024',
        url: 'https://www.it-connect.fr/cyberattaque-france-travail-mars-2024-fuite-donnees-43-millions-de-personnes/',
        usage: 'Chronologie de l’intrusion et analyse du risque d’usurpation d’identité.',
      },
      {
        auteur: 'Solutions Numériques',
        titre: 'France Travail de nouveau ciblé : les données de 340 000 demandeurs d’emploi exposées',
        date: '23 juillet 2025',
        url: 'https://www.solutions-numeriques.com/france-travail-de-nouveau-cible-les-donnees-de-340-000-demandeurs-demploi-exposees/',
        usage: 'Attaque Kairos : alerte du CERT-FR, origine par infostealer sur un compte partenaire.',
      },
      {
        auteur: 'Arx One',
        titre: 'Quelles cyberattaques ont marqué 2024 en France ?',
        date: '2024',
        url: 'https://www.arxone.com/actualites/quelles-cyberattaques-ont-marque-2024-en-france/',
        usage: 'Interpellations du 17 mars 2024 et mise en contexte des attaques de l’année.',
      },
    ],
  },
  {
    categorie: 'Presse généraliste',
    items: [
      {
        auteur: 'franceinfo',
        titre: 'Cyberattaque : France Travail condamné à une amende de 5 millions d’euros par la Cnil',
        date: '22 janvier 2026',
        url: 'https://www.franceinfo.fr/internet/securite-sur-internet/cyberattaques/cyberattaque-france-travail-condamne-a-une-amende-de-5-millions-d-euros-par-la-cnil_7771793.html',
        usage: 'Montant de la sanction, manquements retenus, injonction de surveillance, réaction de France Travail.',
      },
      {
        auteur: 'Banque des Territoires / AFP',
        titre: 'France Travail victime d’une cyberattaque, 340 000 demandeurs d’emploi potentiellement concernés',
        date: '23 juillet 2025',
        url: 'https://www.banquedesterritoires.fr/france-travail-victime-dune-cyberattaque-340000-demandeurs-demploi-potentiellement-concernes',
        usage: 'Confirmation officielle de l’incident Kairos et nature des données consultées.',
      },
      {
        auteur: 'ICI (ex-France Bleu / France 3)',
        titre: 'Cyberattaque à France Travail : la direction avait été informée d’une faiblesse dans la sécurité',
        date: '2024',
        url: 'https://www.ici.fr/infos/economie-social/cyberattaque-a-france-travail-la-direction-avait-ete-informee-d-une-faiblesse-dans-la-securite-2197217',
        usage: 'Dates de l’intrusion selon le parquet ; écart entre le chiffre communiqué et le volume réellement dérobé.',
      },
    ],
  },
]

function SourcesSection() {
  return (
    <section className="section-contenu">
      <div className="mb-4">
        <span className="surtitre">Sources</span>
        <h3 className="h2 fw-bold text-dark">Références utilisées</h3>
        <p className="text-secondary mb-0">
          Les sources sont classées par niveau de fiabilité décroissant : documents institutionnels
          et communiqués officiels d’abord, analyses spécialisées ensuite, presse généraliste enfin.
          Lorsque les sources divergent — notamment sur le nombre de personnes concernées — l’écart
          est signalé dans le corps du site plutôt que résolu arbitrairement.
        </p>
      </div>

      {sources.map((groupe) => (
        <div className="boit-sous-section" key={groupe.categorie}>
          <h4 className="h5 fw-bold text-dark mb-3">{groupe.categorie}</h4>
          <ul className="liste-sources">
            {groupe.items.map((item) => (
              <li key={item.titre}>
                <span className="source-auteur">{item.auteur}</span>
                {' — '}
                <a className="lien-article" href={item.url} target="_blank" rel="noreferrer">
                  {item.titre}
                </a>
                {' — '}
                <span className="source-date">{item.date}</span>
                <p className="mb-0 text-secondary">{item.usage}</p>
              </li>
            ))}
          </ul>
        </div>
      ))}

      <div className="boit-sous-section">
        <h4 className="h5 fw-bold text-dark mb-3">Note sur la fiabilité des sources</h4>
        <p className="text-secondary mb-0">
          Deux précautions ont guidé la rédaction. D’une part, la méthode exacte du vol
          d’identifiants (appel téléphonique frauduleux) est rapportée par Zataz mais n’a pas été
          confirmée dans les communications officielles de France Travail ni dans la décision de la
          CNIL : elle est donc présentée comme telle, attribuée à sa source. D’autre part, le
          chiffre de 43 millions correspond à une estimation haute de précaution et non à un nombre
          de victimes avérées ; il est systématiquement mis en regard des 36,8 millions retenus par
          la CNIL.
        </p>
      </div>
    </section>
  )
}

export default SourcesSection
