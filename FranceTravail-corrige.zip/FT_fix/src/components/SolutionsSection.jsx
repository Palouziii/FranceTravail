const remediations = [
  {
    icon: '🛡️',
    title: 'MFA résistant à l’hameçonnage',
    text: (
      <>
        Le facteur supplémentaire ne suffit pas : il faut choisir le bon. Un code temporaire (TOTP)
        reçu sur une application ou par SMS reste <strong>transmissible</strong> : un attaquant qui
        manipule sa victime par téléphone lui demande simplement le code et l’utilise dans les
        trente secondes. Seules les méthodes fondées sur{' '}
        <strong>FIDO2 / WebAuthn</strong> — clé physique ou authentification intégrée à l’appareil —
        résistent, parce que la clé vérifie cryptographiquement le domaine du site et refuse de
        répondre à un site tiers. Appliquée au périmètre Cap emploi, cette seule mesure aurait
        neutralisé la chaîne d’attaque dès son deuxième maillon.
      </>
    ),
    source: 'ANSSI — recommandations relatives à l’authentification multifacteur',
  },
  {
    icon: '🧱',
    title: 'Cloisonnement applicatif et moindre privilège',
    text: (
      <>
        L’enjeu n’est pas la segmentation réseau — l’attaque n’était pas une intrusion — mais le{' '}
        <strong>cloisonnement des habilitations dans l’application</strong>. Un conseiller affecté à
        un département ne doit pouvoir consulter que les dossiers de ce département, et uniquement
        les champs nécessaires à sa mission. S’y ajoutent une revue périodique des habilitations et
        la révocation automatique des comptes partenaires inactifs.
      </>
    ),
    source: 'ANSSI — principe du moindre privilège ; CNIL',
  },
  {
    icon: '📡',
    title: 'Limitation de débit et détection comportementale',
    text: (
      <>
        Un conseiller consulte quelques dizaines de dossiers par jour, pas plusieurs milliers. Deux
        mécanismes complémentaires s’imposent : un <strong>quota de requêtes</strong> par compte et
        par période, qui bloque mécaniquement l’extraction de masse, et une{' '}
        <strong>détection comportementale</strong> (UEBA) qui alerte sur les écarts par rapport au
        profil d’usage habituel — volume, horaires, dispersion géographique des recherches. C’est
        exactement ce que la CNIL a enjoint à France Travail de mettre en place.
      </>
    ),
    source: 'CNIL, injonction du 22 janvier 2026',
  },
  {
    icon: '🔏',
    title: 'Protection des identifiants pérennes',
    text: (
      <>
        Le numéro de sécurité sociale est la donnée la plus sensible de la fuite, parce qu’elle est
        inchangeable. Il doit être <strong>chiffré au repos</strong>, et surtout remplacé par un
        identifiant technique sans valeur hors du système (<strong>tokenisation</strong>) dans tous
        les écrans et exports où sa valeur réelle n’est pas indispensable. Une extraction massive ne
        livre alors que des jetons inexploitables.
      </>
    ),
    source: 'RGPD, article 32 — pseudonymisation et chiffrement',
  },
  {
    icon: '🔗',
    title: 'Maîtrise du risque fournisseur',
    text: (
      <>
        Les deux attaques sont passées par un tiers : Cap emploi en 2024, un organisme de formation
        en 2025. Les accès partenaires doivent relever d’une{' '}
        <strong>logique de confiance zéro</strong> : exigences de sécurité contractualisées,
        vérification de la conformité du partenaire, journalisation renforcée et surveillance
        spécifique de ces accès, considérés comme la surface d’attaque la plus exposée.
      </>
    ),
    source: 'ANSSI — maîtrise du risque numérique lié aux prestataires',
  },
  {
    icon: '🎓',
    title: 'Sensibilisation et exercices',
    text: (
      <>
        La sensibilisation ne doit pas se limiter à une formation annuelle. Elle suppose des{' '}
        <strong>exercices réalistes</strong> — campagnes d’hameçonnage simulées, mises en situation
        d’appels frauduleux — et une règle claire et sans exception : aucun identifiant ni code
        n’est communiqué par téléphone, y compris à un interlocuteur se présentant comme un
        collègue ou un service support.
      </>
    ),
    source: 'ANSSI — bonnes pratiques de sensibilisation',
  },
]

const organization = [
  {
    title: 'Détection et réponse à incident',
    text:
      'Quatre semaines d’exfiltration non détectée traduisent un défaut de supervision. Une capacité de détection opérationnelle en continu, associée à un plan de réponse éprouvé par des exercices de crise, aurait réduit la fenêtre d’exposition de plusieurs semaines à quelques heures. En 2025, c’est le CERT-FR — et non France Travail — qui a donné l’alerte.',
    source: 'Analyse — ANSSI, CERT-FR',
  },
  {
    title: 'Transparence et accompagnement des victimes',
    text:
      'La notification à la CNIL doit intervenir sous 72 heures, et l’information des personnes concernées dans les meilleurs délais lorsque le risque est élevé. Au-delà de l’obligation, l’accompagnement conditionne l’efficacité : une victime prévenue et informée des modes opératoires frauduleux devient le dernier rempart contre l’exploitation des données volées.',
    source: 'RGPD, articles 33 et 34',
  },
]

function SolutionsSection() {
  return (
    <section className="section-contenu">
      <div className="mb-4">
        <span className="surtitre">V. Protections</span>
        <h3 className="h2 fw-bold text-dark">Quelles mesures pour réduire le risque ?</h3>
        <p className="text-secondary mb-0">
          Chaque mesure ci-dessous répond à un maillon précis de la chaîne d’attaque décrite en
          section II. L’ordre de présentation correspond à l’ordre d’efficacité : bloquer l’entrée,
          puis limiter la portée d’un compte compromis, puis détecter l’abus, puis réduire la valeur
          de ce qui peut être volé.
        </p>
      </div>

      <div className="row g-4">
        {remediations.map((item) => (
          <div className="col-lg-4 col-md-6" key={item.title}>
            <article className="card h-100 border-0 shadow-sm rounded-4">
              <div className="card-body">
                <div className="icone-carte" aria-hidden="true">
                  {item.icon}
                </div>
                <h4 className="h5 fw-bold text-dark mb-3">{item.title}</h4>
                <p className="mb-0 text-secondary">{item.text}</p>
                <small className="source-label d-block mt-3">Source : {item.source}</small>
              </div>
            </article>
          </div>
        ))}
      </div>

      <div className="boit-sous-section mt-4">
        <h4 className="h5 fw-bold text-dark mb-3">Correspondance entre failles et contre-mesures</h4>
        <div className="table-responsive">
          <table className="table tableau-correspondance align-middle mb-0">
            <thead>
              <tr>
                <th scope="col">Maillon de l’attaque</th>
                <th scope="col">Contre-mesure</th>
                <th scope="col">Effet attendu</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Vol d’identifiants par ingénierie sociale</td>
                <td>MFA FIDO2 / WebAuthn</td>
                <td>Un identifiant volé devient inutilisable seul</td>
              </tr>
              <tr>
                <td>Accès national depuis un compte local</td>
                <td>Cloisonnement par périmètre, moindre privilège</td>
                <td>Un compte compromis n’expose qu’une fraction des données</td>
              </tr>
              <tr>
                <td>Requêtes massives non détectées</td>
                <td>Quotas de requêtes, détection comportementale</td>
                <td>Blocage automatique et alerte en quelques minutes</td>
              </tr>
              <tr>
                <td>Valeur des données extraites</td>
                <td>Chiffrement et tokenisation du NIR</td>
                <td>Les données exfiltrées perdent leur exploitabilité</td>
              </tr>
              <tr>
                <td>Chaîne de confiance avec les tiers</td>
                <td>Confiance zéro, audits, journalisation renforcée</td>
                <td>Le partenaire cesse d’être le maillon faible</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div className="boit-sous-section mt-4">
        <h4 className="h5 fw-bold text-dark mb-3">Mesures organisationnelles et humaines</h4>
        <div className="row g-4">
          {organization.map((item) => (
            <div className="col-lg-6" key={item.title}>
              <article className="card h-100 border-0 shadow-sm rounded-4">
                <div className="card-body">
                  <h4 className="h5 fw-bold text-dark mb-3">{item.title}</h4>
                  <p className="mb-0 text-secondary">{item.text}</p>
                  <small className="source-label d-block mt-3">Source : {item.source}</small>
                </div>
              </article>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default SolutionsSection
