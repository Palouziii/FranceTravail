const enjeux = [
  {
    title: 'Rôle central de France Travail',
    text:
      'France Travail centralise les données de millions de citoyens : état civil, coordonnées et numéro de sécurité sociale. Des identifiants de conseillers Cap emploi ont été compromis, puis utilisés pour interroger la base à l’échelle nationale, et non dans le seul périmètre géographique correspondant à leur mission. La défaillance n’était donc pas locale : elle tenait à l’étendue des droits attachés à ces comptes.',
    source: 'France Travail, communiqué du 13 mars 2024',
  },
  {
    title: 'Historique de l’attaque',
    text:
      'Les accès frauduleux ont débuté le 6 février 2024 et se sont poursuivis jusqu’au 5 mars, sous la forme d’une extraction massive et progressive. Ils n’ont pas été repérés sur le moment : c’est seulement au début du mois de mars que l’activité anormale a été identifiée, soit près d’un mois après la première connexion illégitime.',
    source: 'Communiqué du parquet de Paris, 19 mars 2024',
  },
  {
    title: 'Impact humain et réglementaire',
    text: (
      <>
        Sont potentiellement concernés les demandeurs d’emploi inscrits, ceux inscrits au cours des
        vingt dernières années, ainsi que les personnes disposant d’un espace candidat sur
        francetravail.fr. Conformément au RGPD, la notification à la CNIL doit intervenir dans les
        72 heures suivant la prise de connaissance de la violation (
        <a
          className="lien-article"
          href="https://www.cnil.fr/fr/reglement-europeen-protection-donnees/chapitre4#Article33"
          target="_blank"
          rel="noreferrer"
        >
          article 33
        </a>
        ), et les personnes concernées doivent être informées dans les meilleurs délais lorsque le
        risque est élevé (
        <a
          className="lien-article"
          href="https://www.cnil.fr/fr/reglement-europeen-protection-donnees/chapitre4#Article34"
          target="_blank"
          rel="noreferrer"
        >
          article 34
        </a>
        ).
      </>
    ),
    source: 'RGPD, articles 33 et 34',
  },
]

function ContexteSection() {
  return (
    <section className="section-contenu">
      <div className="mb-4">
        <span className="surtitre">I. Contexte &amp; chronologie</span>
        <h3 className="h2 fw-bold text-dark">Comprendre l’incident, son déroulement et son impact</h3>
      </div>

      <div className="row g-4">
        {enjeux.map((item) => (
          <div className="col-lg-4" key={item.title}>
            <article className="card h-100 border-0 rounded-4">
              <div className="card-body">
                <h4 className="h5 fw-bold text-dark mb-3">{item.title}</h4>
                <p className="mb-0 text-secondary">{item.text}</p>
                <small className="source-label d-block mt-3">Source : {item.source}</small>
              </div>
            </article>
          </div>
        ))}
      </div>

      <div className="chronologie-bloc mt-4">
        <h4 className="h5 fw-bold text-dark mb-3">Déroulement de l’incident</h4>
        <ol className="chronologie-liste">
          <li>
            <span className="date-chronologie">Janvier – début février 2024</span>
            <p>
              Des conseillers du réseau Cap emploi sont ciblés par ingénierie sociale afin de leur
              dérober identifiants et mots de passe. Selon Zataz, le vecteur employé est l’appel
              téléphonique frauduleux (<em>vishing</em>) ; les communications officielles de France
              Travail et de la CNIL, plus prudentes, évoquent une « usurpation de comptes de
              conseillers Cap emploi » sans préciser la méthode.
            </p>
          </li>
          <li>
            <span className="date-chronologie">6 février 2024</span>
            <p>
              Première connexion illégitime enregistrée dans le système d’information central. Les
              attaquants utilisent des comptes authentiques : aucune faille logicielle n’est
              exploitée, ce qui rend leur activité difficile à distinguer d’un usage normal.
            </p>
          </li>
          <li>
            <span className="date-chronologie">6 février – 5 mars 2024</span>
            <p>
              L’extraction se déroule sur près de quatre semaines. En se faisant passer pour des
              conseillers, les attaquants enchaînent les requêtes pour récupérer des blocs entiers
              de données d’état civil, en tirant parti de droits d’accès très supérieurs au besoin
              réel. Point critique : aucun mécanisme interne ne signale ce volume anormal de
              consultations.
            </p>
          </li>
          <li>
            <span className="date-chronologie">Début mars 2024</span>
            <p>
              L’activité suspecte est enfin détectée. Les comptes compromis sont bloqués et les
              accès des partenaires au système sont renforcés.
            </p>
          </li>
          <li>
            <span className="date-chronologie">8 mars 2024</span>
            <p>
              France Travail notifie officiellement la violation de données à la CNIL, dans le délai
              de 72 heures imposé par l’article 33 du RGPD.
            </p>
          </li>
          <li>
            <span className="date-chronologie">13 mars 2024</span>
            <p>
              L’incident est rendu public. France Travail et Cap emploi annoncent la fuite par
              communiqué et déposent plainte auprès de la section cybercriminalité du parquet de
              Paris.
            </p>
          </li>
          <li>
            <span className="date-chronologie">17 – 19 mars 2024</span>
            <p>
              Trois personnes sont interpellées, mises en examen et placées en détention provisoire
              dans le cadre de l’enquête. Le 19 mars, le communiqué de la procureure de la
              République précise que l’intrusion s’est déroulée du 6 février au 5 mars inclus.
            </p>
          </li>
        </ol>
        <small className="source-label d-block mt-3">
          Sources : France Travail, parquet de Paris, Zataz, IT-Connect — voir la section Sources
        </small>
      </div>
    </section>
  )
}

export default ContexteSection
