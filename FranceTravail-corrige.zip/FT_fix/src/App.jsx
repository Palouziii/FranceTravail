import { useState, useEffect, useRef } from 'react'
import './App.css'
import Header from './components/Header'
import HomeSection from './components/HomeSection'
import ContexteSection from './components/ContexteSection'
import CauseSection from './components/CauseSection'
import DonneesSection from './components/DonneesSection'
import MenacesSection from './components/MenacesSection'
import SolutionsSection from './components/SolutionsSection'
import BilanSection from './components/BilanSection'
import SourcesSection from './components/SourcesSection'

const navItems = [
  { id: 'accueil', label: 'Accueil' },
  { id: 'contexte', label: 'I. Contexte & chronologie' },
  { id: 'cause', label: 'II. Causes & vulnérabilités' },
  { id: 'donnees', label: 'III. Données exposées' },
  { id: 'menaces', label: 'IV. Menaces & conséquences' },
  { id: 'solutions', label: 'V. Protections' },
  { id: 'bilan', label: 'VI. Bilan & récidive' },
  { id: 'sources', label: 'Sources' },
]

const sections = {
  accueil: HomeSection,
  contexte: ContexteSection,
  cause: CauseSection,
  donnees: DonneesSection,
  menaces: MenacesSection,
  solutions: SolutionsSection,
  bilan: BilanSection,
  sources: SourcesSection,
}

function App() {
  const [activeSection, setActiveSection] = useState('accueil')
  const premierRendu = useRef(true)

  // Remonte en haut de page à chaque changement de section, sauf au premier affichage.
  useEffect(() => {
    if (premierRendu.current) {
      premierRendu.current = false
      return
    }
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }, [activeSection])

  const SectionActive = sections[activeSection] ?? HomeSection

  return (
    <div className="conteneur-principal">
      <Header navItems={navItems} activeSection={activeSection} setActiveSection={setActiveSection} />
      <main id="contenu-principal" className="conteneur-section pb-5">
        <SectionActive setActiveSection={setActiveSection} />
      </main>
      <footer className="pied-de-page">
        <p className="mb-0">
          Projet universitaire — IUT de Dijon-Auxerre-Nevers, Université de Bourgogne Europe. Les
          références utilisées sont listées dans la section{' '}
          <button type="button" className="lien-bouton" onClick={() => setActiveSection('sources')}>
            Sources
          </button>
          .
        </p>
      </footer>
    </div>
  )
}

export default App
